import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductserviceService } from 'src/app/service/productservice.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  addForm:FormGroup;
  submitted: boolean=false;
  
    constructor( private router:Router,
       private productservice: ProductserviceService) { }
  
    ngOnInit() {
      this.addForm= new FormGroup({
        id:new FormControl('',[Validators.required, Validators.pattern('[0-9]{1,4}')]),
        name: new FormControl('',[Validators.required, Validators.pattern('[A-Z][a-zA-Z]+')]),
        description:new FormControl('', [Validators.required]),
        price:new FormControl('', [Validators.required])
        })
          }
    
    onSubmit(){
      this.submitted=true;
      if(this.addForm.invalid){
        return;
      }
      this.productservice.createProduct(this.addForm.value).subscribe(data=>
        {
          alert(this.addForm.controls.value+'record added');
        });
        this.router.navigate(['products']);
    }

}
