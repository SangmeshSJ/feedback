import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductserviceService } from 'src/app/service/productservice.service';

@Component({
  selector: 'app-editproduct',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.css']
})
export class EditproductComponent implements OnInit {
  editForm:FormGroup;
  submitted: boolean=false;
  constructor( private router:Router,
    private productservice: ProductserviceService) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null){
      let productId=localStorage.getItem("editProductId");
      if(!productId){
        alert('Invalid action');
        this.router.navigate(['products']);
return;
      }
      this.editForm= new FormGroup({
        id:new FormControl('',[Validators.required, Validators.pattern('[0-9]{1,4}')]),
        name: new FormControl('',[Validators.required, Validators.pattern('[A-Z][a-zA-Z]+')]),
        description:new FormControl('', [Validators.required]),
        price:new FormControl('', [Validators.required])
        })
  this.productservice.getProductById(+productId).subscribe(data=>{
    this.editForm.setValue(data)
  });
    }
    else{
      this.router.navigate(['/login']);
    }
   
  }

  onSubmit(){
    this.submitted=true;
    if(this.editForm.invalid){
      return;
    }
    this.productservice.updateProduct(this.editForm.value).subscribe(data=>
      {
        this.router.navigate(['products']); 
      }, error=>{
        alert('error');
      });   
  }

}
