import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { L2formComponent } from './l2form.component';

describe('L2formComponent', () => {
  let component: L2formComponent;
  let fixture: ComponentFixture<L2formComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ L2formComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(L2formComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
