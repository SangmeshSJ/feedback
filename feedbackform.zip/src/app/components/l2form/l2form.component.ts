import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-l2form',
  templateUrl: './l2form.component.html',
  styleUrls: ['./l2form.component.css']
})
export class L2formComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
