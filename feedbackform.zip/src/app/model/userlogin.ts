export class Userlogin{
     email:String;
     password:String
}