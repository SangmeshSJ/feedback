import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserloginService {

  baseurl: string= "http://localhost:3000/userlogins";

  constructor() { }
}
